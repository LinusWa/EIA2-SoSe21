Zur Installation muss der Gesamte Oberordner "Endaufgabe" Entpackt werden, mit der selben Ordnerstruktur wie in der Zip Datei.
Um das am leichtesten zu erreichen reicht ein Rechtsklick auf die Zip-Datei, dann "Alle Extrahieren". Wenn hier nichts verändert wird,
wird direkt im gleichen Ordner, in dem sich das Archiv befindet, ein neuer Ordner erstellt und alle Verlinkungen funktionieren!
Dieser Ordner kann auch nach belieben verschoben werden, solange am Inhalt nichts verändert wird.

Zur Ausführung des Programmes muss dann lediglich die Datei mit den namen "index.html" geöffnet werden.

Um Komplikationen zu vermeiden empfiehlt sich eine aktuelle Version des Chrome Browser mit einer Auflösung von 1920 x 1080 Pixel. 
Andere Browser und Auflösungen sollten funktionieren, wurden aber nicht getestet.

Die Benutzung ist simpel:

Durch Klick auf den Startknopf oder per Leertaste startet das Spiel. Dann Bewegen sich die Spieler auf den Ball zu. Sobald ein Spieler
am Ball ist, pausiert das Spiel und du als Nutzer darfst entscheiden wo der Ball hingeschossen werden soll. Das passiert ganz einfach per
Klick auf das Spielfeld. Unter dem Spielfeld siehst du wer aktuell am Ball ist, und auch wenn der Ball ins Aus fliegt oder ein Tor fällt.
Darunter findest du 3 Slider für die Attribute der Spieler. Dort kannst du die Minimalen und Maximalen Werte für Geschwindigkeit, Genauigkeit
und Schusskraft einstellen. Die Werte der Spieler sind dann zufällig in dem eingestellten Bereich. Die Standardeinstellungen sind bereits
für ein schwieriges, aber mögliches Spielerlebnis eingestellt. Probiere trotzdem gerne selbst andere Einstellungen aus!

Links und Rechts des Spielfeldes befindet sich die Ersatzbank. Dort kannst du durch Klick auf das Farbige Viereck ganz einfach die Farbe
der Mannschaften auswählen. Wenn du einen neuen Spieler einwechseln möchtest, kannst du diesen einfach auf den Spieler ziehen, den du
auswechseln möchtest.

Mittig über dem Spielfeld findet sich der aktuelle Spielstand und die aktuelle Zeit. Diese werden automatisch aktualisiert.

Für Recht und Ordnung sorgen zwei Linienrichter und ein Schiedsrichter. Diese greifen allerdings nicht in das geschehen ein.


Im Unterordner findet sich außerdem das Konzept.

Viel Spaß :)